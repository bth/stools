======
stools
======

:Description: Tools for automate tasks on machines with only ssh
:License:     GPL
:Homepage:    TODO
:API docs:    TODO
:Development: https://github.com/bth/stools


What
----

"stools" is a module for Python 2.6+ that help you to automate tasks on machines
across network.

It is written entirely in Python.


Requirements
------------

- `Python <http://www.python.org/>`_ 2.6+
- `Paramiko <http://www.paramiko.org/>`_ 1.15+


Installation
------------

TODO


Bugs & Support
--------------

:Bug Reports:  `Github <https://github.com/bth/stools/issues/>`_


