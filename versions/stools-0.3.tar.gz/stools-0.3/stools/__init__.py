"""
.. automodule:: stools.main
   :members:

.. automodule:: stools.Colors
   :members:

.. automodule:: stools.Command
   :members:

.. automodule:: stools.Configuration
   :members:

.. automodule:: stools.Copy
   :members:

.. automodule:: stools.Machine
   :members:

.. automodule:: stools.Recovery
   :members:

.. automodule:: stools.Task
   :members:
"""

